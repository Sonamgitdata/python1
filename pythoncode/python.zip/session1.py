print("welcome to python")
