# while loop

while [condition]:
    [statements]
else:

    1-20 number
count = 1
sum = 0

while count <= 20:
    sum = sum + count
    count = count + 1
print(sum)
