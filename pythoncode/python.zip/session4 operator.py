# operators in python
# 1 Arithmetic operators +,-,*,/,//,%,**power operator
# 2 comparison operators <,>,<=,>=,==,!=
# 3 identity operator
# 4assignment operator =,+=,-+,*=,/=
# bitwise operator
# logical operators
# membership operators in  not in
num1=10
num2=20
print(num1+num2)
print(num1-num2)
print(num1*num2)
print(num1/num2)
# true division float value
print(10/3)   
# floor devision int value
print(10//3)
print(10%3)

print(45**2)

# comparison operator
num1=300
num2=200
print(num1<num2)

# identity operator compare the memory locations
num1=100
num2=100
print(num1==num2)
print(num1 is num2)
 
l=  [10,20,30]
l2= [10,20,30]

print(l == l2)
print(l is l2)

# assignment operator
num1=100
num1=num1+5
print(num1)
num1-= 5
print(num1)

# bitwise operator

num1=2
num2=1
print(bin(num1),bin(num2))
print(num1 & num2)
print(num1 | num2)
print(2>>1)
print(bin(2))
print(2<<1)
# logical operators

print(10==15 or 20==20)
print(not(10==15))

# membership opearator

l=[10,20,30,40]
print(50 in l)
s="python string"
print("String" not in s)
print("string" in s)