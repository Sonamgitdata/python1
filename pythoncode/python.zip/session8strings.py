# string:
# s='' "" """ """
# string are immutable -cant modify on same memory location
# string is ordered data structure-indexing and slicing




from _typeshed import SupportsLenAndGetItem


s="pyhton sample"
print(type(s))
s1="pyhthon"
print(id(s1))
s1="java"
print(id(s1))

# left to right indexing

s="python sample string"
print(s[7])

# right to left indexing

s="python sample string"
print(s[-4])


# slicing

s="python sample string"
# print(s[0:6])

# print(s[7:])
# print(s[:6])

# alternate character stride-

print(s[::2])
print(s[::3])

# stride from right to left

print(s[::-2])
# slicing

print(s[6:0])

s="python sample string"
for value in s:
    print(value)

s="python sample string"
for value in s[::2]:
    print(value)

help(str)

# string  are immutable on same memory loc cant change

s="python sample string"
print(id(s))
s=s.capitalize()
print(s)
print(id(s))

# upper
# lower 
# title

s="python sample string"
# print(s.upper())
# # print(s.lower())
s=s.capitalize()
s=s.upper()
print(s.isupper())



s="HTML,CSS,PYTHON,JAVA,DJANGO"

l =s.split(",")
print(l)
 
s1=(" ").join(l)
print(s1)


s1="abcd"
s2="1234"
s3="python sample string abcd"
table=str.maketrans(s1,s2)
result=s3.translate(table)
print(result)


# maketrans
# translate

# Index
# Find
# rfind function



s="HTML,CSS,PYTHON,PYTHON"
print("PYTHON" in s)
# print(s.index("PYTHON"))

# print(s.find("PYTHON"))
print(s.rfind("PYTHON"))

s="        this is sample string      "
s1=s.strip(" ")
s1=s.lstrip(" ")
s1=s.rstrip(" ")

print(s1)


s="python"
# s1=s.center(20,"*")
s1=s.rjust(20,"*")
s1=s.ljust(20,"*")

print(s1)



s="HTML,CSS,PYTHON,PYTHON,HTML"
s1=s.replace("HTML","HTML5")
print(s1)

print(dir(str))



