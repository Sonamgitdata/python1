import pandas as pd
list = [['apple','red'],['banana','yellow'],['orange','orange']]
mydataframe = pd.DataFrame(list)
mydataframe