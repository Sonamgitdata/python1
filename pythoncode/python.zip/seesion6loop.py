# loops in python
# for loop
# while loop

# for[variable name] in [iterable data type]:
#     statements

l = [10,20,30,40,50]
sum = 0
# sum = 0+10 =10
# 10+20=30
# 30+30=60
for value in l:
    
    sum = sum + value
print(sum)


range(5) 0 1 2 3 4 5
range(10,100) 10,11,12,13,14....99
range(10,100,5) 10 ,15,20,25,30,35... 95,100
sum = 0
for value in range(1,21):
    sum = sum + value
print(sum)





