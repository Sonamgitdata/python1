# immutable data structure
# ordered indexing and slicing
# tuple:
t=(10,20,20,30,40,50,60,70)
# print(t,type(t))
# help(tuple)
# print(t[10])
# print(t[:3])
# print(t.index(20))
# print(t.count(20))

l=[10,20,30,40,50]
for t in enumerate(l):
    print(t[1])
l=[10,20,30,40,50]
t=tuple(l)
print(t)


t=("a","b","c",100)
l=list(t)
print(l,type(l))