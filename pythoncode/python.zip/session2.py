first_num = 10
second_num = 20
addition = first_num + second_num
print(addition)


# # ID
# # type
print(type(first_num),type(second_num))
print(id(first_num),id(second_num))

a = 10
b = 10 

print(id(a),id(b))
# object intering means a and b using same memory  location beacause both have same value