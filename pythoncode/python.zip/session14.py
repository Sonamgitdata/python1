# code reuse:
# modularity

s = "python,html,css"
print(s.index("html"))

# func call
# fun def

def value_reverse(value):
    reverse = value[::-1]
    print(reverse)
s = "pyhton"
result = value_reverse(s)

l = [10,20,30,40]
print(l.append(50))
print(l)

l =[100,200,300,400]
result = value_reverse(l)
num=100
result = value_reverse(s)
print(result)

def value_reverse(value):
    if type(value) == list or type(value) ==   str:
      reverse = value[::-1]
    else:
        temp = str(value)
        reverse = temp[::-1]
    return reverse
l =[100,200,300,400]
result = value_reverse(l)
print(result)
num=100
result = value_reverse(num)
print(result)
