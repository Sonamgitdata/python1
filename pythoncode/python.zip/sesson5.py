# # conditional statement
# if[condition]:
#     statements
# elif[condition]:    
# else:
#     statements    
num1 = 100
num2 = 200
if num1 > num2:
   print("num1 is greater than num2")
   print("another statement")
elif num2 > num1:
   print("num2 is greater than num1")
else:
   print("num1 and num2 are equal")


if 1:
       print("statement in if block")
else: 
      print("statement in else block")
