# cust id
# name
# balance
# deposite
# withdraw

class Account:
    def __init__(self,cust_id,name,initial_bal=0):
        self.__id = cust_id
        self.__name = name
        self.__balance = initial_bal
       
    def get_balance(self):
            return self.__balance
    def get_id(self):
        return self.__id        

    def get_name(self):
        return self.__name 
    def deposite(self,amount):
        self.__balance = self.__balance + amount
        return self.__balance  
    def withdraw(self,amount):
        if amount > self.__balance:
            return "insufficient balance"
        else:
             
         self.__balance -= amount  
        return self.__balance


customer1 = Account("101","ABC")
# it will show all the variable for this perticular object
print(customer1.__dict__)

# acccessing of private variable within class-standard way
print(customer1._Account__id)
# Account(customer1,"101","ABC")
# print(customer1)

customer2 = Account("102","xyz")
# print(customer1)
# print(customer1.id,customer1.name,customer1.balance)
print(customer1.get_balance()) 
print(customer1.deposite(50000))

# print(customer2.get_balance()) 
print(customer1.withdraw(40000))
customer3 = Account("103","PQR")
customer4 = Account("104","QME")

customer2.deposite(8000)
customer3.deposite(30000)
customer4.deposite(40000)

l = [customer1,customer2,customer3,customer4]
for obj in l:
        if obj.get_balance() < 10000:
            print(obj.get_id(),obj.get_name())



print(customer1.get_balance)