# open file

# r-read
# r+
# w-write
# w+
# a-append
# a+
from os import read, write


fp = open("timebucks.txt","r")
content = fp.read()
print(content)

print("---------------")
content = fp.read()
print(content)


readlines
readline
fp = open("timebucks.txt","r")
# content = fp.readlines()
content = fp.readline()
print(content)
print(content)
print(content[:5])
print(type(content))

# what will happen?
for x in fp:
    print((x))


# tell-current fp file pointer position

# seek-to change the file pointer position

    # write- in write we cant read
fp = open("timebucks.txt","w+")
print(fp.tell())
fp.write("write this line in to afile")    
print(fp.tell())
fp.seek(0,0)
print(fp.tell())
# fp = open("timebucks.txt","w")
# fp.write("next sample line")    
content = fp.read()
print(fp.tell())
print(content)

# seek(offset,position)-to change the file pointer position

offset = number of characters
position=0 start of File
          1 current position
          2 end of File
seek(15,0) = change the fp by 15 char from start of the file    
seek(0,2)= change fp by 0 char from end of the file
# seek(15,1) not allowed
# seek(15,2)  not allowed

r+= read+write
fp = open("timebucks.txt","r+")
content = fp.read()
print(content)
fp.write("\n\n sample line added")





# r,r+,w,w+,=fp is at start
# a and a+ = fp at the end   a is append
a only can write
a+ both read write

fp = open("timebucks.txt","a+")
print(fp.tell())
content = fp.read()
print(content)

content = fp.read()

# append a only write operation perform
fp = open("timebucks.txt","a")
content = fp.write("\n\n\nabcd")
print(content)

# a+ -read write operation
fp = open("timebucks.txt","a+")
content = fp.read()
print(content)


# r = fp =start,file should exist,read
# r+ = fp =start,file should already exist,read+write

# w= fp = start, create a new file,write
# w+ = fp = start,create a new file ,write +read

# a = fp = end, create a new file, write at the end
# a+ = fp =end ,create a new file, write + read