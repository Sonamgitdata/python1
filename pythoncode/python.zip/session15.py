# positional argument-# linear search
# default argument
# keyword argument
# variable at positional argument
# variable length keyword argument

def linear_search(L,KEY):
    for value in l:
        if key == value:        
          return True
    else:
        return False    

l=[100,200,300,400,500]
key = 600
result =linear_search(l,key)
print(result)

# default argument pwd creation
#  8 char
#  1 upper
#  1 lower
#  1 special char
#  5 digits

# ord gives ascii value 97 -122
# chr

print(ord('a'),ord('z'))
print(ord('A'),ord('Z'))
print(chr(97))

import random
def gen_password(length=8):
    l = ['@','#','$','&']

    upper = chr(random.randint(65,90))
    lower = chr(random.randint(97,122))
    special = random.choice(l)
    digit = random.randint(10000,99999)
    password = upper + lower + special +str(digit)
    l = random.sample(password,length)
    print(l)
    password = ("").join(l)
    return password

result = gen_password()
print(result)

# keyword argument

def validate(username,password):
    if username == "ABC" and password == "Abc@123":
        print("valid password")
    else:
        print("invalid password")


validate("ABC","Abc@123")
validate(password="Abc@123",username ="ABC")

help(print)

print(100,200,sep=',',end=" ")
print("hi")


#  variable at positional argument

l=[100,200,300,400]
l.append(500)
print(l)

def add_value(*args):
    print(args)

# for add more value
add_value(100,200,300,400,500)

add_value(100,200)

# for tuple

def add_value(*args):
    l = []
    for value in args:
        l.append(value)
    return l

result = add_value(100,200,300,400,500,600,700)   
print(result) 
result = add_value(100,200)  
print(result)  

#  variable length keyword argument
# name ,email,contact,dob
def get_details(**kwargs):
    print(kwargs)

get_details(name ="ABC",email="abc@gmail.com",contact= 9029051545,dob ="1-05-1987")
get_details(name ="ABC",email="abc@gmail.com",dob ="12-05-1987")
get_details(name= "ABC",contact= 66723523,dob= "12-06-1986")
