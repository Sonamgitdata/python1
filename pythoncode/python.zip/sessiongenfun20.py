# generators
# if there infinite values generator function gives one value at a time
# infinte fabonnacci series
# gen funtion maintain the state of function
# generator reduces memory consumption
def printval(l):
    for value in l:
        print(value)

l = [10,20,30,40,50,60]
printval(l)

# fibonacci series
def fibo():

   first_num = 0
   second_num = 1
   yield second_num
   while(True):
     next_val = first_num + second_num
     yield next_val
     first_num,second_num = second_num,next_val

g = fibo()
# print(next(g))
# print(next(g))
# print(next(g))
# print(next(g))

for value in range(10):
    print(next(g))
for value in range(20):
    print(next(g))


# print values using generators

def printval(l):
    for value in l:
        yield value
l = [10,20,30,40,50,60]
g = printval(l)
print(next(g))    
print(next(g)) 
print(next(g)) 
print(next(g))    


# generator exception handling

l = [10,20,30,40,50,60]
# comprehension thats y () brackets put in list
l2 = (value * value for value in l)
# print(l2)
print(next(l2))
print(next(l2))
print(next(l2))
print(next(l2))





