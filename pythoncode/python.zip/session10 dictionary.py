# dict:
# mutable
# unordered
# key should be unique
# keys should be immutable

from typing import ItemsView, KeysView


d = {"emp_id":101,"name":"ABC","email":"abc@gmail.com"}
print(d)
# add operation
# d["contact_no"] = 9412567083
# print(d)
# # update operation
# d["contact_no"] = 902906983
# print(d)

# print(d["emp_id"])

# get
# setdefault
# print(d.get("age",-1))
# print(d.setdefault("age",50))
# print(d)

# for key in d:
#     print(key,d[key])

# d={}
# # 1 : 1,2:4,3:9.......10 :100    
# for value in range(1,11):
#     d[value]=value*value
#     print(d)


    # Keys
    # values
    # Items

    # print(d.keys())
    # print(d.values())
    # print(d.items())

d = {"emp_id":101,"name":"ABC","email":"abc@gmail.com"}  
for t in d.items():
 print(t)
 