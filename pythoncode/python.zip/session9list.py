# list
# list are muttable-can add,update and delete
# ordered indexing and slicing
# 3 heterogeneous datatype means number and string both can add
from types import ClassMethodDescriptorType


l=[10,20,30,40,"Python","java",[100,200,300]]
# print(l,type(l))

# indexing and slicing


# print(l[-1][1])
# print(l[20])
# print(l[1:3])
print(l[::-1])



l=[100,200,300,400,500]
for value in l[::2]:
    print(value)


#     # append
# num1=100
# print(id(num1))
# # print(id(l))
# # l.append(600)
# print(id(l[0]))
# print(l)


# extend
l=[100,200,300,400,500]
# l.extend([500,600,700,800])
# l.append([500,600,700,800])
# l.extend("python")
l.insert(1,1000)
print(l)

l=[10,20,30]
# l2=l
l2=l.copy()
l.append(40)
print(l,l2)
print(id(l),id(l2))

# update and delete
# pop
# remove
# clear
# del

# remove by index we use pop
l=[10,20,30,40,50]
l[2]=300
print(l)


# r=l.pop()
r=l.pop(1)

print(l,r)

# delete by no.we use remove
l=[10,20,20,30,40,50]
# l.remove(20)
# print(l)
# l.remove(20)
# print(l)

l.clear()
print(l)

l=[10,20,20,30,40,50]
del l
print(l)

l=[50,40,10,30,20]
# print(l.sort())
# print(l)
# print(l[::2])
# print(l[::-1])
# l.reverse()
# print(l)
l3=sorted(l)
print(l3)

l=[50,40,10,30,20]
print(l.index(20))

l=[50,40,10,30,30,20]
print(l.count(30))


l=[10,20,30,40]
l2=[100,200,300]
print(l+l2)

l=[0.1]
print(l*10)

