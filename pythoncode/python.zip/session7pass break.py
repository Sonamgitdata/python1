# break
# continue
# enumerate for for loop

# for value in range(10):
#     print(value)

l = [10,20,30,40,50,60] 
key = 300
# for value in l:
for index,value in enumerate(l):
    print(index,value)
    if value == key:
        print("element found at index",index)
        break
    else:
        pass
        # print("satement after continue statement")   
else:
    print("element not found")  
print("statement after for loop")      

for index,value in enumerate(l):
    print(index,value)


    