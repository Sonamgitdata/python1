# datatypes
#1 int
num1=100
print(type(num1))

# 2 float
num2=15.25
print(type(num2))

# int and float are immutable datatypes means we cant change value
num1=100
print(id(num1))
num1=105
print(id(num1))

# 3 string data type
s="'python' sample string"
print(id(s))
print(s,type(s))

s= "new value"
print(id(s))

# 4 list :[] in list we can add,delete and update the data from same memory location,muttable

l = [10,20,30,40,50,"python","django"]
print(id(l))

# for adding element

l.append(60) 
print(id(l))  
print(l)

# 5 tuple- helping multiple datatype element immutable-inwhich we cant add ,delete and update
t=(10,20,30)

# 6 dict -key and value seprated by : :muttable data type
d={"name":"ABC,"email":"abc@gamil.com"}

# 7 Set- we can add,update and delete ,muttable operation like union intersection
s={10,20,30,40}

# 8 bool- true false
# 9 complex : 4+3j


help(string)